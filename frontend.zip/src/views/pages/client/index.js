export { default as Dashboard } from './dashboard'
export { default as Profile } from './profile'
