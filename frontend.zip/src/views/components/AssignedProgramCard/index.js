export { default } from './AssignedProgramCard'
