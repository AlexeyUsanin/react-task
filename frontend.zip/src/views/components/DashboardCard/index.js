export { default } from './DashboardCard'
