import React, { useMemo, memo, useEffect, useCallback } from 'react'
import {
  Form,
  FieldArray,
  getFormValues,
  Field,
  getFormAsyncErrors,
  change,
} from 'redux-form'
import { useSelector, useDispatch } from 'react-redux'

import { Box, Button, makeStyles } from '@material-ui/core'

import TimeTableCard from '~/views/components/TimeTableCard'
import AutocompleteField from '~/views/shared/fields/AutocompleteField'
import BottomFormAction from '~/views/components/BottomFormAction'
import ChangeNameModal from '~/views/components/ChangeNameModal'

import { getWorkoutOptions } from '~/state/modules/workout'
import { getNutritionOptions } from '~/state/modules/nutrition'
import { updateProgram } from '~/state/modules/programs'

import { DAYS_OF_WEEK } from '~/utilities/constants'

const useStyles = makeStyles(theme => ({
  content: {
    display: 'flex',
    flexDirection: 'column',
    flex: 1,
    marginBottom: 140,
  },

  nutritionField: {
    marginTop: theme.spacing(2),
    width: '35%',
    [theme.breakpoints.down('sm')]: {
      width: '100%',
    },
  },

  addWeek: {
    padding: '10px 24px;',
  },
}))

const RenderTimetableCard = ({
  name,
  weekTimetable,
  index,
  formName,
  fields,
  workoutOpts,
  deleteTasks,
}) => {
  const dispatch = useDispatch()

  const menuData = useMemo(
    () => [
      {
        label: 'Delete',
        onClick: () => {
          fields.remove(index)
          const ids = []
          Object.values(weekTimetable).forEach(values =>
            values.forEach(({ id }) => {
              if (id) ids.push(id)
            })
          )
          dispatch(change(formName, 'delete_tasks', [...deleteTasks, ...ids]))
        },
      },
      {
        label: 'Copy a week',
        onClick: () => {
          const itemCopy = Object.entries(fields.get(index)).reduce(
            (accumulator, [dayName, tasks]) => {
              accumulator[dayName] = tasks.map(({ label, value }) => ({
                label,
                value,
              }))
              return accumulator
            },
            {}
          )
          return fields.push(itemCopy)
        },
      },
    ],
    [deleteTasks, dispatch, fields, formName, index, weekTimetable]
  )

  return (
    <Box my={2}>
      <TimeTableCard
        formName={formName}
        name={name}
        weekTitle={`Week ${index + 1}`}
        weekTimetable={weekTimetable}
        menuData={menuData}
        workoutOpts={workoutOpts}
      />
    </Box>
  )
}

const RenderWeeks = ({ fields, meta, workoutOpts }) => {
  const classes = useStyles()
  const { weeks, delete_tasks } = useSelector(getFormValues(meta.form))

  const defaultValues = useMemo(
    () =>
      Object.keys(DAYS_OF_WEEK).reduce((accumulator, day) => {
        accumulator[day] = []
        return accumulator
      }, {}),
    []
  )

  return (
    <Box className={classes.content}>
      {fields.map((week, index) => (
        <RenderTimetableCard
          key={week}
          index={index}
          name={week}
          weekTimetable={weeks[index]}
          fields={fields}
          formName={meta.form}
          workoutOpts={workoutOpts}
          deleteTasks={delete_tasks || []}
        />
      ))}
      <Box my={2} mx="auto">
        <Button
          color="secondary"
          className={classes.addWeek}
          onClick={() => fields.push(defaultValues)}
          disabled={fields.length >= 48}
        >
          + Add week
        </Button>
      </Box>
    </Box>
  )
}

const CreateTimetableForm = ({
  handleSubmit,
  modal,
  modalState,
  dispatch,
  form,
  submitting,
  pristine,
  submitFailed,
  reset,
  valid,
  name,
  program_id,
  nutrition_id,
}) => {
  const classes = useStyles()
  const nutritionOptions = useSelector(getNutritionOptions)
  const workoutOpts = useSelector(getWorkoutOptions)
  const errors = useSelector(getFormAsyncErrors(form))

  useEffect(() => {
    if (errors?.name && submitFailed && !modal) {
      modalState.show()
    }
  }, [errors, modal, modalState, submitFailed])

  const handleSubmitForm = useCallback(async () => {
    await dispatch(updateProgram({ name, program_id, nutrition_id }))
  }, [dispatch, name, nutrition_id, program_id])

  return (
    <Form onSubmit={handleSubmit}>
      <Field name="delete_tasks" component={() => null} />
      <Box className={classes.nutritionField}>
        <Field
          name="nutrition_id"
          component={AutocompleteField}
          options={nutritionOptions}
          label="Select nutrition"
        />
      </Box>
      <FieldArray
        name="weeks"
        component={RenderWeeks}
        workoutOpts={workoutOpts}
      />

      <BottomFormAction formProps={{ pristine, submitting }} />
      <ChangeNameModal
        open={modal}
        inputLabel="Program name"
        title="Rename program"
        handleClose={modalState.hide}
        handleSubmit={handleSubmitForm}
        handleReset={reset}
        fieldValid={valid}
        formProps={{ pristine, submitting }}
      />
    </Form>
  )
}

export default memo(CreateTimetableForm)
